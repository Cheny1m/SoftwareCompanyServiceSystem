package cn.edu.sicnu.cs.validation;

import javax.validation.groups.Default;

/**
 * 自定义参数检测组
 * @Classname Create
 * @Description TODO
 * @Date 2020/12/17 14:12
 * @Created by Huan
 */
public interface Create extends Default {
}
