package cn.edu.sicnu.cs.validation;

import javax.validation.groups.Default;

/**
 * @Classname Update
 * @Description TODO
 * @Date 2020/12/17 14:13
 * @Created by Huan
 */
public interface Update extends Default {
}
