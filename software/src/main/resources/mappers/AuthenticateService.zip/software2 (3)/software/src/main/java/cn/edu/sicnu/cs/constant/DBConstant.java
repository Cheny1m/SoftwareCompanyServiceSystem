package cn.edu.sicnu.cs.constant;

/**
 * @Classname DeletedType
 * @Description TODO
 * @Date 2020/11/19 22:17
 * @Created by Huan
 */
public class DBConstant {
    public final static String DELETED="1";
    public final static String NOTDELETED="0";
    public final static String UNLOCK="0";
    public final static String LOCKED="1";
}
