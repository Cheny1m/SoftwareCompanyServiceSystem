package cn.edu.sicnu.cs.pojo;

/**
 * @Classname PrivGroup
 * @Description TODO
 * @Date 2020/11/23 10:18
 * @Created by Huan
 */
public class PrivGroup {

//    public static

}
