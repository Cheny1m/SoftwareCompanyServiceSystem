package cn.edu.sicnu.cs.constant;

/**
 * @Classname AliyunConstant
 * @Description TODO
 * @Date 2020/12/14 20:17
 * @Created by Huan
 */
public class AliyunConstant {
    public final static String CAPTCHA_CODE_TEMPLATE = "SMS_195220958";
    public final static String RESET_PASSWORD_TEMPLATE = "SMS_206747645";
    public final static String SIGNNAME = "aboysky";
    public final static String ACCESS_KEY = "LTAI4GJCMFr1HexxQ8GBCFXp";
    public final static String ACCESS_SECRET = "U6oOAuctY95Wj5mVfUllQ1iEordmAG";
}
