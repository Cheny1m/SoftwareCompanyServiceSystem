package cn.edu.sicnu.cs.controller;

import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.asymmetric.RSA;
import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.RestController;

import java.security.PublicKey;

/**
 * @Classname EncyptController
 * @Description TODO
 * @Date 2020/12/15 12:13
 * @Created by Huan
 */
@RestController
@Api(tags = "加密解密操作")
public class EncyptController {

//    public String getPublicKey(byte[] bytes){
//        RSA rsa = new RSA();
//
//    }

}
