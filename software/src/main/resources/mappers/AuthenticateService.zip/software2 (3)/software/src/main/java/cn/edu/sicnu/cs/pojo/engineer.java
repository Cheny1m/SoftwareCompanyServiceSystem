package cn.edu.sicnu.cs.pojo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class engineer {

    private int uid;

    private String urealname;

    private String rname;

    private String fzname;

}
