package cn.edu.sicnu.cs.validation;

import javax.validation.groups.Default;

/**
 * @Classname Delete
 * @Description TODO
 * @Date 2020/12/17 14:13
 * @Created by Huan
 */
public interface Delete extends Default {
}
