package cn.edu.sicnu.cs.constant;

/**
 * @Classname UserConstant
 * @Description TODO
 * @Date 2020/11/16 21:48
 * @Created by Huan
 */
public interface UserConstant {
    /**
     * 用户正常状态
     */
    String USER_STATUS_NORMAL = "enable";
}
